# -*- coding:utf-8 -*-
"""
Represents connection end-points to Outscale APIs
"""

import urlparse
from boto.ec2.regioninfo import RegionInfo
from icu import ICUConnection


def connect_icu(url, aws_access_key_id='', aws_secret_access_key='', login='', password='', **kwargs):
    """
    Connect to an ICU Api endpoint.
    Additional arguments are passed to ICUConnection.

    :param str url: Url for the icu api endpoint to connect to
    :param str aws_access_key_id: Your AWS Access Key ID
    :param str aws_secret_access_key: Your AWS Secret Access Key
    :param str login: Your login email ID
    :param str password: Your raw password to login
    :param dict kwargs:
    :return class: `outscale.boto.icu.ICUConnection`
    """
    purl = urlparse.urlparse(url)
    kwargs['port'] = purl.port
    kwargs['path'] = purl.path
    if not 'is_secure' in kwargs:
        kwargs['is_secure'] = (purl.scheme == "https")

    kwargs['host'] = RegionInfo(name=purl.hostname, endpoint=purl.hostname).endpoint
    kwargs['aws_access_key_id'] = aws_access_key_id
    kwargs['aws_secret_access_key'] = aws_secret_access_key
    kwargs['login'] = login
    kwargs['password'] = password

    return ICUConnection(**kwargs)
